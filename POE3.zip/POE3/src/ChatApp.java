import javax.swing.JOptionPane;
import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.JSONObject;

public class ChatApp {

    static String storedUsername;
    static String storedPassword;
    static String storedCell;
    static int messageCount = 0;
    static String[] sentMessages = new String[100];
    static String[] storedMessages = new String[100];
    static String[] discardedMessages = new String[100];
    static String[] messageHashes = new String[100];
    static String[] messageIds = new String[100];
    static int totalMessages = 0;

    public static void main(String[] args) {

        storedUsername = JOptionPane.showInputDialog("Enter username:");
        while (!checkUserName(storedUsername)) {
            storedUsername = JOptionPane.showInputDialog("Username incorrect. Try again:");
        }

        storedPassword = JOptionPane.showInputDialog("Enter password:");
        while (!checkPasswordComplexity(storedPassword)) {
            storedPassword = JOptionPane.showInputDialog("Password incorrect. Try again:");
        }

        storedCell = JOptionPane.showInputDialog("Enter your phone number:");
        while (!checkCellPhoneNumber(storedCell)) {
            storedCell = JOptionPane.showInputDialog("Phone number incorrect. Try again:");
        }

        JOptionPane.showMessageDialog(null, "Registration successful!");

        String inputUsername = JOptionPane.showInputDialog("Enter username to login:");
        String inputPassword = JOptionPane.showInputDialog("Enter password to login:");

        if (!loginUser(inputUsername, inputPassword)) {
            JOptionPane.showMessageDialog(null, "Username or password incorrect.");
            return;
        }

        JOptionPane.showMessageDialog(null, "Welcome back!");

        int messageLimit = Integer.parseInt(JOptionPane.showInputDialog("How many messages would you like to enter?"));
        int sentCount = 0;

        while (true) {
            String option = JOptionPane.showInputDialog(
                "1. Send Message\n2. Show Sent Messages\n3. Longest Message\n4. Search by ID\n5. Search by Recipient\n6. Delete by Hash\n7. Show Report\n8. Quit"
            );

            if (option == null) break;
            int choice = Integer.parseInt(option);

            switch (choice) {
                case 1:
                    if (sentCount >= messageLimit) {
                        JOptionPane.showMessageDialog(null, "Message limit reached.");
                        break;
                    }

                    String recipient = JOptionPane.showInputDialog("Enter recipient number:");
                    if (!checkCellPhoneNumber(recipient)) {
                        JOptionPane.showMessageDialog(null, "Invalid number.");
                        break;
                    }

                    String message = JOptionPane.showInputDialog("Enter message (max 250 chars):");
                    if (message.length() > 250) {
                        JOptionPane.showMessageDialog(null, "Too long by " + (message.length() - 250));
                        break;
                    }

                    String id = generateMessageId();
                    String hash = createMessageHash(id, totalMessages + 1, message);
                    String action = JOptionPane.showInputDialog("Send / Store / Discard");

                    switch (action.toLowerCase()) {
                        case "send":
                            sentMessages[totalMessages] = message;
                            messageHashes[totalMessages] = hash;
                            messageIds[totalMessages] = id;
                            JOptionPane.showMessageDialog(null, "Message sent.");
                            break;
                        case "store":
                            storedMessages[totalMessages] = message;
                            messageHashes[totalMessages] = hash;
                            messageIds[totalMessages] = id;
                            storeMessage(id, recipient, message, hash);
                            JOptionPane.showMessageDialog(null, "Message stored.");
                            break;
                        case "discard":
                            discardedMessages[totalMessages] = message;
                            JOptionPane.showMessageDialog(null, "Message discarded.");
                            break;
                        default:
                            JOptionPane.showMessageDialog(null, "Invalid option.");
                            continue;
                    }

                    JOptionPane.showMessageDialog(null,
                        "ID: " + id +
                        "\nHash: " + hash +
                        "\nRecipient: " + recipient +
                        "\nMessage: " + message);

                    totalMessages++;
                    sentCount++;
                    break;

                case 2:
                    StringBuilder out = new StringBuilder("Sent Messages:\n");
                    for (int i = 0; i < totalMessages; i++) {
                        if (sentMessages[i] != null) {
                            out.append("To: ").append(storedCell)
                               .append(" | Msg: ").append(sentMessages[i]).append("\n");
                        }
                    }
                    JOptionPane.showMessageDialog(null, out.toString());
                    break;

                case 3:
                    String longest = "";
                    for (int i = 0; i < totalMessages; i++) {
                        if (sentMessages[i] != null && sentMessages[i].length() > longest.length()) {
                            longest = sentMessages[i];
                        }
                    }
                    JOptionPane.showMessageDialog(null, "Longest message:\n" + longest);
                    break;

                case 4:
                    String searchId = JOptionPane.showInputDialog("Enter message ID:");
                    boolean foundById = false;
                    for (int i = 0; i < totalMessages; i++) {
                        if (messageIds[i] != null && messageIds[i].equals(searchId)) {
                            JOptionPane.showMessageDialog(null, "Found:\n" + sentMessages[i]);
                            foundById = true;
                            break;
                        }
                    }
                    if (!foundById) {
                        JOptionPane.showMessageDialog(null, "Message ID not found.");
                    }
                    break;

                case 5:
                    String recipientSearch = JOptionPane.showInputDialog("Enter recipient number:");
                    StringBuilder match = new StringBuilder();
                    for (int i = 0; i < totalMessages; i++) {
                        if (sentMessages[i] != null && storedCell.equals(recipientSearch)) {
                            match.append("Msg: ").append(sentMessages[i]).append("\n");
                        }
                    }
                    JOptionPane.showMessageDialog(null, match.length() == 0 ? "No matches." : match.toString());
                    break;

                case 6:
                    String hashSearch = JOptionPane.showInputDialog("Enter message hash:");
                    boolean deleted = false;
                    for (int i = 0; i < totalMessages; i++) {
                        if (messageHashes[i] != null && messageHashes[i].equals(hashSearch)) {
                            sentMessages[i] = null;
                            messageHashes[i] = null;
                            messageIds[i] = null;
                            JOptionPane.showMessageDialog(null, "Message deleted.");
                            deleted = true;
                            break;
                        }
                    }
                    if (!deleted) {
                        JOptionPane.showMessageDialog(null, "Hash not found.");
                    }
                    break;

                case 7:
                    JOptionPane.showMessageDialog(null,
                        "QuickChat Report\n" +
                        "Total Messages: " + totalMessages + "\n" +
                        "Sent: " + countArray(sentMessages) + "\n" +
                        "Stored: " + countArray(storedMessages) + "\n" +
                        "Discarded: " + countArray(discardedMessages));
                    break;

                case 8:
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                    return;

                default:
                    JOptionPane.showMessageDialog(null, "Invalid selection.");
            }
        }
    }

    public static boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    public static boolean checkPasswordComplexity(String password) {
        return password.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*()_+=<>?]).{8,}$");
    }

    public static boolean checkCellPhoneNumber(String number) {
        return number.matches("^\\+\\d{10,13}$");
    }

    public static boolean loginUser(String username, String password) {
        return storedUsername.equals(username) && storedPassword.equals(password);
    }

    public static String generateMessageId() {
        long num = (long) (Math.random() * 1_000_000_0000L);
        return String.format("%010d", num);
    }

    public static String createMessageHash(String id, int count, String message) {
        String[] words = message.trim().split("\\s+");
        String first = words.length > 0 ? words[0].toUpperCase() : "";
        String last = words.length > 1 ? words[words.length - 1].toUpperCase() : "";
        return id.substring(0, 2) + ":" + count + ":" + first + last;
    }

    public static void storeMessage(String id, String recipient, String message, String hash) {
        JSONObject obj = new JSONObject();
        obj.put("messageId", id);
        obj.put("messageNumber", messageCount + 1);
        obj.put("recipient", recipient);
        obj.put("messageText", message);
        obj.put("messageHash", hash);

        try (FileWriter file = new FileWriter("messages.json", true)) {
            file.write(obj.toJSONString() + System.lineSeparator());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static int countArray(String[] arr) {
        int count = 0;
        for (String s : arr) {
            if (s != null) count++;
        }
        return count;
    }
}

