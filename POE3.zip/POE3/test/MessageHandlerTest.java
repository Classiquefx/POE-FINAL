import org.junit.Before;
import org.junit.Test;
import java.util.List;
import org.junit.jupiter.api.Test;

public class MessageHandlerTest {

    private MessageHandler handler;

    @Before
    public void setUp() {
        handler = new MessageHandler();
    }

    @Test
    public void testGenerateUniqueId() {
        String id1 = handler.generateMessageId();
        String id2 = handler.generateMessageId();
        assertNotEquals(id1, id2);
        assertEquals(10, id1.length()); // assuming 10-digit IDs
    }

    @Test
    public void testHashMessage() {
        String message = "HelloWorld";
        String hash = handler.hashMessage(message);
        assertNotNull(hash);
        assertTrue(hash.length() > 0);
    }

    @Test
    public void testStoreMessage() {
        Message msg = new Message("1234567890", "+27123456789", "Test", "hashcode");
        handler.storeMessage(msg);
        Object messages = handler.getAllMessages();
        assertTrue(messages.contains(msg));
    }

    @Test
    public void testSearchByRecipient() {
        Message msg = new Message("1234567890", "+27110000000", "Hello", "hash1");
        handler.storeMessage(msg);
        List<Message> result = handler.searchByRecipient("+27110000000");
        assertFalse(result.isEmpty());
        assertEquals("Hello", result.get(0).getContent());
    }

    @Test
    public void testInvalidMessageNotStored() {
        Message invalidMsg = new Message("", "", "", "");
        handler.storeMessage(invalidMsg);
        assertFalse(handler.getAllMessages().contains(invalidMsg)); // assuming validation blocks it
    }

    private void assertNotEquals(String id1, String id2) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertEquals(int i, int length) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertNotNull(String hash) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertTrue(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
